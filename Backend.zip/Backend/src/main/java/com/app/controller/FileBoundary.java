package com.app.controller;

import java.io.IOException;
import java.net.URI;

import javax.validation.constraints.NotNull;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.app.dao.FileEntityRepository;
import com.app.pojos.FileEntity;


@RestController
@RequestMapping("/api/files")
@CrossOrigin(value = {"*"}, exposedHeaders = {"Content-Disposition"})
public class FileBoundary {

  private final FileEntityRepository fileEntityRepository;

  public FileBoundary(FileEntityRepository fileEntityRepository) {
    this.fileEntityRepository = fileEntityRepository;
  }

  
  @Transactional
  @GetMapping("/fetch/{subject_id}")
  public ResponseEntity<byte[]> getRandomFile(@PathVariable int subject_id) {


    FileEntity fileEntity = fileEntityRepository.findBySubjectId(subject_id);

    HttpHeaders header = new HttpHeaders();

    header.setContentType(MediaType.valueOf(fileEntity.getContentType()));
    header.setContentLength(fileEntity.getData().length);
    header.set("Content-Disposition", "attachment; filename=" + fileEntity.getFileName());

    return new ResponseEntity<>(fileEntity.getData(), header, HttpStatus.OK);
  }

 
  @Transactional
  @PostMapping("/upload/{subject_id}")
  public ResponseEntity<Void> uploadNewFile(@PathVariable int subject_id,@NotNull @RequestParam("file") MultipartFile multipartFile) throws IOException {

   FileEntity fileEntity = new FileEntity( multipartFile.getOriginalFilename(), multipartFile.getContentType(),
      multipartFile.getBytes(), subject_id);
     
    fileEntityRepository.save(fileEntity);

    URI location = ServletUriComponentsBuilder.fromCurrentRequest().build().toUri();
    return ResponseEntity.created(location).build();

  }

}