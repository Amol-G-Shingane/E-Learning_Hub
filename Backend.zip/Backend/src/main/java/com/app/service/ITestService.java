package com.app.service;

import java.util.List;

import com.app.dto.TestDTO;
import com.app.pojos.Test;

public interface ITestService {
	
	Test addTestDetails(TestDTO testDTO, int subjectId );
	public Test updateTestDetails(int testId,TestDTO test);
	
	public List<Test> getTestDetails(int testId);
 	
}
