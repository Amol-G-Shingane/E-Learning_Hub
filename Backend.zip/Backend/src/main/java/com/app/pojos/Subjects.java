package com.app.pojos;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "subjects")
public class Subjects extends BaseEntity {
	
	@NotBlank(message = "Subject name can't be blank")
	@Column(nullable = false, unique = true,length = 20)
	private String name;
	
	@ManyToMany(cascade = {CascadeType.MERGE,CascadeType.PERSIST},mappedBy = "subjects")
	@JsonIgnoreProperties("subjects")
	private Set<Courses> courses=new HashSet<>();
	
	
	
	@OneToMany(mappedBy = "subjectTests", cascade = CascadeType.ALL,orphanRemoval = true ,fetch = FetchType.EAGER)
	@Fetch(FetchMode.JOIN)
	private List<Test> tests=new ArrayList<>();

	public Subjects() {
	
	}
	
	
	
	public Subjects(@NotBlank(message = "Subject name can't be blank") String name, Set<Courses> courses, List<Test> tests) {
		super();
		this.name = name;
		this.courses = courses;
		
		this.tests = tests;
	}



	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@JsonIgnore
	public Set<Courses> getCourses() {
		return courses;
	}

	@JsonIgnore
	public void setCourses(Set<Courses> courses) {
		this.courses = courses;
	}
	

	@JsonIgnore
	public List<Test> getTests() {
		return tests;
	}
	@JsonIgnore
	public void setTests(List<Test> tests) {
		this.tests = tests;
	}

	public void addTest(Test t)
	{
		tests.add(t);
		t.setSubjectTests(this);
	}
	public void removeTest(Test t)
	{
		tests.remove(t);
		t.setSubjectTests(null);
	}	
		
}
