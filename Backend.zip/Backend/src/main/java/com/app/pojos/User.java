package com.app.pojos;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "users")
public class User extends BaseEntity{
	

@NotEmpty(message = "First name is required")	
@NotBlank(message = "User name can't blank")

private String name;


@NotEmpty(message = "Email is required")

private String email;


private String password;


private String dob;

@Enumerated(EnumType.STRING)
private Role role;



@ManyToMany(cascade = {CascadeType.MERGE,CascadeType.PERSIST})
@JoinTable(name = "user_test", joinColumns=
@JoinColumn(name = "user_id"),
inverseJoinColumns = @JoinColumn(name = "test_id"))

@JsonIgnoreProperties("users")
private Set<Test> tests =new HashSet<Test>();


public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

public String getDob() {
	return dob;
}

public void setDob(String dob) {
	this.dob = dob;
}

public Role getRole() {
	return role;
}

public void setRole(Role role) {
	this.role = role;
}

@JsonIgnore
public Set<Test> getTests() {
	return tests;
}

@JsonIgnore
public void setTests(Set<Test> tests) {
	this.tests = tests;
}


}
