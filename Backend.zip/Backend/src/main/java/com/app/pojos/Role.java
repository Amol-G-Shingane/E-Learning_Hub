package com.app.pojos;

public enum Role {
USER,ADMIN,EMPLOYEE;
}
