package com.app.pojos;

import java.util.Arrays;

import javax.persistence.*;

@Entity
@Table(name = "notes")
public class FileEntity extends BaseEntity {


  private String fileName;

  private String contentType;

  @Lob
  private byte[] data;
  
  private int subjectId;

  public FileEntity() {
  }

public FileEntity(String fileName, String contentType, byte[] data, int subjectId) {
	super();
	this.fileName = fileName;
	this.contentType = contentType;
	this.data = data;
	this.subjectId = subjectId;
}

public String getFileName() {
	return fileName;
}

public void setFileName(String fileName) {
	this.fileName = fileName;
}

public String getContentType() {
	return contentType;
}

public void setContentType(String contentType) {
	this.contentType = contentType;
}

public byte[] getData() {
	return data;
}

public void setData(byte[] data) {
	this.data = data;
}

public int getSubjectId() {
	return subjectId;
}

public void setSubjectId(int subjectId) {
	this.subjectId = subjectId;
}

@Override
public String toString() {
	return "FileEntity [fileName=" + fileName + ", contentType=" + contentType + ", data=" + Arrays.toString(data)
			+ ", subjectId=" + subjectId + "]";
}

 
  
}