import { useDispatch, useSelector } from 'react-redux'
import { Link } from 'react-router-dom'
import { logout } from '../actions/userActions'

const Footer = (props) => {
  

  return (

    <div class='footer-container'>
  
      <div class='footer-links'>
        <div class='footer-link-wrapper'>
          <div class='footer-link-items'>
            <h2>About Us</h2>
            <Link to='/signup'>How it works</Link>
            
            <Link to='/'>Careers</Link>
            
            {/* <Link to='/'>Terms of Service</Link> */}
          </div>
          <div class='footer-link-items'>
            <h2>Contact Us</h2>
            <Link to='/'>Contact</Link>
            <Link to='/'>Support</Link>
            
          </div>
        </div>
        <div class='footer-link-wrapper'>
          
          <div class='footer-link-items'>
            <h2>Social </h2>
            <Link to='/'>Instagram</Link>
            <Link to='/'>Facebook</Link>
            <Link to='/'>Youtube</Link>
            
          </div>
        </div>
      </div>
    
    </div>
   
  )
}

export default Footer
