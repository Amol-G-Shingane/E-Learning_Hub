import { useDispatch, useSelector } from 'react-redux'
import { Link } from 'react-router-dom'
import { logout, signin } from '../actions/userActions'


const Navigations = (props) => {
    const dispatch = useDispatch()
  const userSignin = useSelector((store) => store.userSignin)

  const onLogout = () => {
    dispatch(logout())
  }


    return (
      <div>
        <div class="topnav" id="myTopnav">       
          <a href="/about">Contact Us</a>
          <a href="/home">Home</a>
          <a className ='float-end' href="/signup">Signup</a>
          <a className ='float-end' href="/signin">Signin</a>
          <a className ='float-end' href="/signin">Logout</a>
           <a href="javascript:void(0);" class="icon" onclick="myFunction()">&#9776;</a>
</div>

     
      </div>  
    )
  }
  
 
  
  export default Navigations
  