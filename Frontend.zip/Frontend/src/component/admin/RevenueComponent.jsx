// import React, { Component } from 'react'
// import AdminApiService from "../../service/AdminApiService";

// class RevenueComponent extends Component {

//     constructor(props) {
//         super(props)
//         this.state = {
//             revenue: [],
           
//              message: null
//         }
//         // this.deleteUser = this.deleteUser.bind(this);
//         // this.editUser = this.getSubjects.bind(this);
        
//         this.reloadRevenueList = this.reloadRevenueList.bind(this);
//     }

//     componentDidMount() {
//         this.reloadRevenueList();
//     }

//     reloadRevenueList() {
//         AdminApiService.fetchRevenue()
//             .then((res) => {
//                 this.setState({revenue: res.data.result})
               

//                 console.log(this.state.revenue);
                
//             });
//             // UserService.getUsers().then(resp => {
//             //     this.setState({ users: resp.data });
//             //     console.log(this.state.users);
//             // })
//     }

   

    

//     render() {
//         return (
//             <div>
//                 <h2 className="text-center">Revenue Details</h2>
                
               

//                 <table class="center">
//   <tr>
//   <th>Revenue</th>
//  <th>Amount</th>
//   </tr>
  
//          {
//             this.state.revenue.map(
//         revenue =>
//     <tr >
                                        
//          <td>{revenue[0]}</td>
//    <td>{revenue[1]}₹</td>
                                       
     
//       </tr>
//                             )
//                         }
                   
  
// </table>


                
                
//                 <a href="/home"><button class="btns info">Back</button></a>
//             </div>
//         );
//     }

// }

// export default RevenueComponent;