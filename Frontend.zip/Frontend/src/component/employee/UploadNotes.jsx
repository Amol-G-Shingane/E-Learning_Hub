import React, { Component } from 'react'
import ApiService from "../../service/ApiService";

class UploadNotes extends Component {

    constructor(props) {
        super(props)
        this.state = {
            courses: [],
            message: null
        }
       
        
        this.reloadCoursesList = this.reloadCoursesList.bind(this);
    }

    componentDidMount() {
        this.reloadCoursesList();
    }

    reloadCoursesList() {
        ApiService.fetchCourses()
            .then((res) => {
                this.setState({courses: res.data.result})
                console.log(this.state.courses);
            });
            // UserService.getUsers().then(resp => {
            //     this.setState({ users: resp.data });
            //     console.log(this.state.users);
            // })
    }

   
    

    render() {
        return (
            <div>
                <h2 className="text-center">Test Details</h2>
                
                <table className="table table-striped">
                    <thead>
                        <tr>
                            
                            <th>Name</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                        {
                            this.state.courses.map(
                        courses =>
                                    <tr >
                                        
                                        <td>{courses.name}</td>
                                        
                                        <td>
                                           
                                            <button className="btn btn-success" onClick={() => this.getTests(subject.name)} style={{marginLeft: '20px'}}> Subjects</button>
                                        </td>
                                    </tr>
                            )
                        }
                    </tbody>
                </table>

            </div>
        );
    }

}

export default UploadNotes;