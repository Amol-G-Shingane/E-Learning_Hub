import React, { Component } from 'react'
import ApiService from "../../service/ApiService";

class EmployeeSubjectsComponent extends Component {

    constructor(props) {
        super(props)
        this.state = {
            subjects: [],
            message: null
        }
       
        this.reloadSubjectsList = this.reloadSubjectsList.bind(this);
    }

    componentDidMount() {
        this.reloadSubjectsList();
    }

    reloadSubjectsList() {
        ApiService.fetchSubjects(window.localStorage.getItem("courseName"))
            .then((res) => {
                
                this.setState({subjects: res.data.result})
                console.log(this.state.subjects);
            });
            
    }

    
    
    addTest(sid){
        window.sessionStorage.setItem("sid", sid);
        this.props.history.push("/add-test")
    }

    getTest(sid){
        window.sessionStorage.setItem("sid", sid);
        this.props.history.push("/viewTest")
    }
    addNotes(sid){
        window.sessionStorage.setItem("sid",sid);
        this.props.history.push("/empnotes")
    }
    render() {
        return (
            <div>
                <h2 className="text-center">Subject Details</h2>
               
                <table className="table table-striped">
                    <thead>
                        <tr>
                           
                            <th>Name</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                        {
                            this.state.subjects.map(
                        subjects =>
                                    <tr >
                                     
                                        <td>{subjects.name}</td>
                                        
                                        <td>
                                    <a href="/subjectsPage">    <button class="button"><span> Continue </span></button> </a>
                                           
                                           
                                        </td>
                                        <td>
                                        <button onClick={() => this.addTest(subjects.id)}  class="btns success">Add Test</button>
                                        <button onClick={() => this.getTest(subjects.id)} class="btns success">View Test</button>
                                        <button onClick={() => this.addNotes(subjects.id)} class="btns success">Add Notes</button>
                                      
                                        </td>
                                    </tr>
                            )
                        }
                    </tbody>
                </table>

            </div>
        );
    }

}

export default EmployeeSubjectsComponent;