

const JobsScreen = (props) => {


    return (
        <div> 
            <marquee>
       <b><i><> <h3> <span class="d-block p-2 bg-dark text-white">Welocome to Jobs sections</span></h3></></i></b></marquee><br></br><hr></hr>
       <b><i><> <a href="https://my.naukri.com/">CG Vyapam Recruitment 2021: Notification Out For Market</a></></i></b><br></br><hr></hr>
       <b><i><> <a href="https://in.indeed.com/">MES Recruitment 2021: Short Notice Out For Supervisor & DraughtsmanPosts; Check Details Here</a></></i></b><br></br><hr></hr>
       <b><i><a href="https://www.timesjobs.com/">IGMC Shimla Recruitment 2021: Apply For 227 Senior Residents/Tutor</a></i></b><br></br><hr></hr>
       <b><i><>  <a href="https://www.freshersworld.com/">WBHRB Staff Nurse Recruitment 2021: Online Application Postponed</a></></i></b><br></br><hr></hr>
       <b><i>  <a href="https://www.monsterindia.com/">JPSC Civil Service Recruitment 2021: Last Date Extended For 252 Deputy Collector</a></i></b><br></br><hr></hr>

        </div>
    )
  }
  
  export default JobsScreen
  