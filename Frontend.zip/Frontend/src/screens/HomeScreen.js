import Header from '../components/Header'
import Navigations from '../components/Navigation'
//import NewNavigation from '../components/NewNavigation'
import CardItem from '../components/CardItem'

import { Link } from 'react-router-dom';
const HomeScreen = (props) => {

  return (
    <div >

      <div class='hero-container'>
        <image src='/images/img-home.jpg' />
        <h1> CDAC E-Learning HUB</h1>
        <p>What are you waiting for? Join Now !</p>


        <a href="/signin">
          <button class="button">
            <span>
              Join Now
            </span>
          </button>
        </a>

      </div>

    </div>

  )
}

export default HomeScreen