import Header from '../components/Header'
import CardItem from '../components/CardItem'

import { Link } from 'react-router-dom';

const AboutScreen = (props) => {
  return (
     
    <div >
    
  
  <div >
  <div class='cards__container'>
        <div class='cards__wrapper'>
          <ul class='cards__items'>
          <CardItem
              src='images/hrushi.JPG'
              text='Hrushikesh Patil hrushi@gmail.com 8149780519'
              path='/home'
            />
            
            <CardItem
              src='images/priya1.jpg'
              text='Priya Kumari priya@gmail.com '
              path='/home'
            />

              <CardItem
              src='images/ganesh.JPG'
              text='Ganesh Rawalekar ganesh@gmail.com'
              path='/home'
            />

            <CardItem
              src='images/amit.jpg'
              text='Amit Bhosale amit@gmail.com'
              path='/home'
            />    
          
          
            <CardItem
              src='images/Manisha.jpg'
              text='Manisha Nikam Manisha@gmail.com'
              path='/home'
            />
            
          </ul>
        </div>
      </div>
      
     

    </div> 

      
  </div>

  )
}

export default AboutScreen
