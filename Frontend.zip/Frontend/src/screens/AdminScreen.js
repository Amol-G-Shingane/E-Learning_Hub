
import { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { getUsers } from '../actions/adminActions'

import CardItem from '../components/CardItem'


const AdminScreen = (props) => {

  const dispatch = useDispatch()
  const user = useSelector((store) => store.user)
  const { error, response, loading } = user

  // call this only once (when the page has loaded successfully)
  useEffect(() => {
    dispatch(getUsers())
  }, [])

  useEffect(() => { }, [error, response, loading])



  return (


    <div class="container"  >

      <div>
        <div class='cards__container'>
          <div class='cards__wrapper'>
            <ul class='cards__items'>

              <CardItem
                src='images/emplyee.jpg'
                text='Teacher'

                path='/emp-list'
              />
              <CardItem
                src='images/user.jpg'
                text='Students'

                path='/user-list'
              />

            </ul>
          </div>
        </div>
      </div>

    </div>

  )
}

export default AdminScreen



