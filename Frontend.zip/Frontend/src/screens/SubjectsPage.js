import Header from '../components/Header'
import CardItem from '../components/CardItem'

import { Link } from 'react-router-dom';
const SubjectsPage = (props) => {
  return (

    <div >
      <div  className='bgimg'>
        <div class='cards__container'>
          <div class='cards__wrapper'>
            <ul class='cards__items'>
              <CardItem
                src='images/notes.jpg'
                text='Notes'

                path='/usernotes'
              />

              <CardItem
                src='images/test.jpg'
                text='Tests'

                path='/userTest'
              />

            </ul>
          </div>
        </div>

      </div>


    </div>
  )
}

export default SubjectsPage
